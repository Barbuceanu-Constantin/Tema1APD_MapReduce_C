#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <math.h>
#include <vector>
using namespace std;

struct my_arg{
    pthread_barrier_t *bariera;
    vector<vector<vector<int>>> *v;
    int nr_entry_files, id_mapper, id_reducer, *file_counter;
    int nr_mappers, nr_reducers;
    char **matrix;
};

void check_perfect_power(unsigned int x, vector<vector<vector<int>>> *v,
                         int id, int nr_reducers) {
    unsigned long long left, right, middle, a, i;
    for(int exp = 2; exp < nr_reducers + 2; ++exp) {
        left = 1;
        right = x;
        while(left <= right) {
            middle = left  + (right - left) / 2;
            a = middle;
            i = 1;
            while(i < exp) {
                a *= middle;
                if(a > x) break;
                ++i;
            }
            if(a == x) {
                (*v)[id][exp-2].push_back(x);
                break;
            } else if(a > x) {
                right = middle - 1;
            } else {
                left = middle + 1;
            }
        }
    }
}

void *mapper(void *arg) {
    struct my_arg* d = (struct my_arg*) arg;
    unsigned int nr_numbers, x, i;
    pthread_mutex_t mutex;
    FILE *fptr;
    int res;

    res = pthread_mutex_init(&mutex, NULL);
	if(res) {
        printf("Eroare alocare mutex in mapper.\n");
        exit(-1);
    }

    while (*(d->file_counter) < d->nr_entry_files - 1) {
        //Deschid fisierul. Actualizez contorul de linie. ZONA CRITICA.
        res = pthread_mutex_lock(&mutex);
        if(res) {
            printf("Eroare la lock in mapper.\n");
            exit(-1);
        }

        (*(d->file_counter))++;
        fptr = fopen(d->matrix[*(d->file_counter)],"r");
        if(fptr == NULL) {
            printf("Eroare la deschiderea fisierului in mapper.\n");
            exit(-1);
        }
	    
        res = pthread_mutex_unlock(&mutex);
        if(res) {
            printf("Eroare la unlock in mapper.\n");
            exit(-1);
        }

        //Citesc numarul de numere din fisierul de input alocat mapperului.
        fscanf(fptr, "%d\n", &nr_numbers);

        for(i = 0; i < nr_numbers; ++i) {
            fscanf(fptr, "%d\n", &x);
            if(x == 1) {
                for(i = 0; i < (*(d->v))[d->id_mapper].size(); ++i)
                    (*(d->v))[d->id_mapper][i].push_back(x); 
            } else {
                check_perfect_power(x, d->v, d->id_mapper, d->nr_reducers);
            }
        }
        fclose(fptr);
    }

    //Se pune bariera la final.
    res = pthread_barrier_wait(d->bariera);
	if( !(res == 0 || res == PTHREAD_BARRIER_SERIAL_THREAD) ) {
        printf("Eroare la asteptatul la bariera in mapper.\n");
        exit(-1);
    }

    //Se distruge mutexul.
    res = pthread_mutex_destroy(&mutex);
	if(res) {
        printf("Eroare la dezalocarea mutexului in mapper.\n");
        exit(-1);
    }

    pthread_exit(NULL);
}

void *reducer(void *arg) {
    struct my_arg* d = (struct my_arg*) arg;
    vector<int> final_list;
    char filename[20], nr[10];
    FILE *fptr;
    int res;

    //Deschid fisierul in care reducerul curent o sa scrie rezultatul.
    strcpy(filename, "out");
    snprintf(nr, sizeof(nr), "%d", d->id_reducer + 2);
    strcat(filename, nr);
    strcat(filename, ".txt");
    fptr = fopen(filename,"w");
    if(fptr == NULL) {
        printf("Eroare la deschiderea fisierului in reducer.\n");
        exit(-1);
    }

    //Se pune bariera la inceput.
    res = pthread_barrier_wait(d->bariera);
	if ( !(res == 0 || res == PTHREAD_BARRIER_SERIAL_THREAD) ) {
        printf("Eroare la asteptatul la bariera in reducer.\n");
        exit(-1);
    }

    //Creez o lista finala de puteri perfecte unice toate cu acelasi exponent
    //determinat de id-ul reducer-ului.
    for(int j = 0; j < d->nr_mappers; ++j) {
        for (int x : (*(d->v))[j][d->id_reducer]) {
            final_list.push_back(x);
        }
    }

    //Elimin duplicatele din final_list.
    for(int i = 0; i < final_list.size() - 1; ++i) {
        for(int j = i + 1; j < final_list.size(); ++j) {
            if(final_list[j] == final_list[i]){
                final_list.erase(final_list.begin() + j);
                --j;
            }
        }
    }

    fprintf(fptr, "%zu", final_list.size());
    
    fclose(fptr);

    pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
    FILE *fptr;
    int nr_mappers, nr_reducers, nr_threads, res, nr_entry_files, file_counter;
    char input_base_file[20], **matrix;
    pthread_barrier_t bariera;
    vector<vector<vector<int>>> v;
    vector<vector<int>> aux1;
    vector<int> aux2;

    //Desetez bufferingul automat al afisarii.
    setvbuf(stdout, NULL, _IONBF, 0);

    //Extrag parametrii din linia de comanda.
    nr_mappers = atoi(argv[1]);
    nr_reducers = atoi(argv[2]);
    nr_threads = nr_mappers + nr_reducers;
    strcpy(input_base_file, argv[3]);

    //Deschid fisierul de baza.
    struct my_arg arg[nr_threads];
    pthread_t threads[nr_threads];
    fptr = fopen(input_base_file, "r");
    if(fptr == NULL) {
        printf("Eroare la deschiderea fisierului de baza in main.\n");
        exit(-1);
    }

    //Initializez bariera dintre maperi si reduceri.
    res = pthread_barrier_init(&bariera, NULL, nr_threads);
    if(res) {
        printf("Eroare la crearea barierei in main.\n");
        exit(-1);
    }

    //Citesc nr-ul de fisiere. Aloc matricea cu numele fisierelor.
    //Citesc numele fisierelor.
    fscanf(fptr, "%d\n", &nr_entry_files);
    matrix = (char **) malloc(sizeof(char *) * nr_entry_files);
    if(!matrix) {
        printf("Eroare la alocarea unei matrici de nume de fisiere.\n");
        exit(-1);
    } else {
        for (int i = 0; i < nr_entry_files; ++i) {
            matrix[i] = (char *)malloc(20);
            fscanf(fptr, "%s\n", matrix[i]);
            if(!matrix[i]) {
                printf("Eroare la alocarea unei linii in matricea de nume.\n");
                exit(-1);
            }
        }
    }

    //Initializez structura v.
    for(int i = 0; i < nr_mappers; ++i)
        v.push_back(aux1);
    for(int i = 0; i < nr_mappers; ++i)
        for(int j = 0; j < nr_reducers; ++j)
            v[i].push_back(aux2);

    //Creez threadurile.
    file_counter = -1;
    for(int i = 0; i < nr_threads; ++i) {
        arg[i].v = &v;
        arg[i].bariera = &bariera;
        arg[i].file_counter = &file_counter;
        arg[i].nr_entry_files = nr_entry_files;
        arg[i].id_mapper = -1;
        arg[i].id_reducer = -1;
        arg[i].matrix = matrix;
        arg[i].nr_mappers = nr_mappers;
        arg[i].nr_reducers = nr_reducers;
        if(i < nr_mappers) {
            arg[i].id_mapper = i;
            pthread_create(&threads[i], NULL, mapper, &arg[i]);
        } else {
            arg[i].id_reducer = i - nr_mappers;
            pthread_create(&threads[i], NULL, reducer, &arg[i]);
        }
    }

    //Astept threadurile create.
    for (int i = 0; i < nr_threads; i++) {
		pthread_join(threads[i], NULL);
	}

    //Distrug bariera.
    res = pthread_barrier_destroy(&bariera);
    if (res) {
        printf("Eroare distrugere bariera in main.\n");
        exit(-1);
    }

    //Dezaloc matricea de nume de fisiere.
    for (int i = 0; i < nr_entry_files; ++i) {
        free(matrix[i]);
    }
    free(matrix);

    fclose(fptr);
    return 0;
}